jQuery(document).ready(function() {
  "use strict";

  jQuery(".__A__Mobile_Actions").on( "click", function() {
    jQuery(".__A__Col_3", jQuery(this).parent() ).show();
  });

});
