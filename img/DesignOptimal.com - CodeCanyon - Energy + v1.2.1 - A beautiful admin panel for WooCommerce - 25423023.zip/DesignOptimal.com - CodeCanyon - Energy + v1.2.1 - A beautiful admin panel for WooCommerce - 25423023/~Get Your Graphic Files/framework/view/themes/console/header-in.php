<?php
if (! defined('ABSPATH')) {
  exit; // Exit if accessed directly
}
?>

<div class="__A__HeaderIn_Div __A__Adjust"></div>
<div class="container">
