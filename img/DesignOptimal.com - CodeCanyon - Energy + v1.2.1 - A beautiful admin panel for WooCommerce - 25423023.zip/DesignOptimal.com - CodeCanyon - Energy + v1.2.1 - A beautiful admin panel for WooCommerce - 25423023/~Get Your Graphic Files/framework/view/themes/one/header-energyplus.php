<?php
if (! defined('ABSPATH')) {
  exit; // Exit if accessed directly
} ?>

<div class="energyplus-content">
  <div class="energyplus-content-in">
